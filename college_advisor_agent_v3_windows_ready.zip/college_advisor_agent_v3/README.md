# College Admissions Advisor Agent — Version 3

Created by **S. Ambooken**

Version 3 expands the college-fit prototype with two new advisor modules:

## New in Version 3

### Medical Pathways
- Traditional pre-med remains available through the normal college recommender.
- Dedicated discovery for BS/MD, BS/DO-type, and early-assurance pathways.
- Program-level planning category is intentionally separate from ordinary undergraduate admission.
- Program details include undergraduate school, medical-school partner, pathway type, continuation requirements, deadline notes, MCAT notes, and verification status.
- Current-cycle rules must be verified on official university/medical-school pages because combined-program structures frequently change.

### Undergraduate Major Finder
- Interest profile covering biology, chemistry, math, coding, business, people-facing work, writing, design/building, healthcare, and research.
- Ranks majors to investigate and explains why each major matches the student's interests.
- Keeps **major choice separate from pre-med requirements**: a pre-med student does not need to major in Biology if medical-school prerequisites are completed.

### Ask the Advisor
Natural-language questions can include:
- Which BS/MD or BS/DO pathways should I investigate?
- Which undergraduate majors fit my interests?
- Which colleges are the strongest fit for my current SAT/GPA/budget?

If `OPENAI_API_KEY` is configured, the advisor can use the OpenAI explanation layer. The deterministic recommendation engine works without it.

### Easier College Scorecard API setup
Paste a College Scorecard/api.data.gov key directly in the sidebar for the current app session. If left blank, V3 uses `COLLEGE_SCORECARD_API_KEY` from Windows or falls back to `DEMO_KEY`.

## Existing V2 features retained
- Live College Scorecard institution metrics when available
- Offline fallback dataset
- GPA and SAT profile
- Geographic radius search (200 miles default)
- Career-area selection
- Reach / Target / Likely / High Reach planning categories
- Fit scoring across admissions, career, finances, outcomes, and location
- Saved student profiles and college list
- Application-status tracking and notes
- College comparison
- Balanced-list check
- Subtle creator credit in the footer

## Run from Python

```bat
py -m pip install -r requirements.txt
py -m streamlit run app.py
```

## Build the Windows executable
Double-click:

`BUILD_WINDOWS_EXE.bat`

The finished launcher will be under:

`dist\CollegeAdmissionsAdvisorV3\CollegeAdmissionsAdvisorV3.exe`

Keep the complete generated `CollegeAdmissionsAdvisorV3` folder together.

## Data cautions
College Scorecard is used for federal institution-level metrics when live access succeeds. Admission categories, career-fit scores, major matches, and combined-medical-pathway competitiveness are advisory heuristics, not admissions probabilities. Always verify current tuition, testing policy, deadlines, prerequisites, pathway continuation rules, and major requirements on official school sites before applying.
