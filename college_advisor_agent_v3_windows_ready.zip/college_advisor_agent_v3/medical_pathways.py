# V3 starter discovery catalog. Program rules change frequently; every row is labeled for verification.
# Two entries below were verified against official pages during V3 creation (Aug 2026).
PROGRAMS = [
    {
        "program":"Special Program in Medicine (SPiM)", "undergrad":"University of Connecticut", "medical_school":"UConn School of Medicine",
        "type":"BA/BS–MD", "state":"CT", "city":"Storrs", "years":"8", "status":"Verified official source Aug 2026",
        "minimums":"Suggested HS GPA 3.5; program continuation requires 3.6 cumulative GPA and MCAT threshold",
        "deadline":"Nov 1 undergraduate application; supplemental due Nov 8 (Fall 2026 page)",
        "mcAT":"Required for continuation", "notes":"Any of 125+ undergraduate majors; Honors enrollment required; program admission is far more selective than general UConn admission.",
        "url":"https://admissions.uconn.edu/apply/first-year/special-programs/medicine/"
    },
    {
        "program":"Program in Liberal Medical Education (PLME)", "undergrad":"Brown University", "medical_school":"Warren Alpert Medical School",
        "type":"AB/ScB–MD", "state":"RI", "city":"Providence", "years":"8", "status":"Verified official source Aug 2026",
        "minimums":"No program-specific published numeric minimum in the official admission page",
        "deadline":"Apply through Brown undergraduate admission; indicate PLME on Common App",
        "mcAT":"See current official PLME requirements", "notes":"Approximately 50 students enroll each year; broad liberal-arts flexibility and any eligible concentration.",
        "url":"https://plme.med.brown.edu/admission"
    },
    {
        "program":"Combined/Accelerated Medical Pathway", "undergrad":"Rensselaer Polytechnic Institute", "medical_school":"Albany Medical College",
        "type":"BS/MD-type", "state":"NY", "city":"Troy", "years":"Verify", "status":"Discovery lead — verify current official program",
        "minimums":"Verify current cycle", "deadline":"Verify current cycle", "mcAT":"Verify current cycle",
        "notes":"Included as a discovery lead because combined-program structures can change. Confirm directly with RPI/Albany Medical College before relying on it.", "url":""
    },
    {
        "program":"Accelerated Medical Program", "undergrad":"New Jersey Institute of Technology", "medical_school":"New Jersey Medical School",
        "type":"BS/MD-type", "state":"NJ", "city":"Newark", "years":"Verify", "status":"Discovery lead — verify current official program",
        "minimums":"Verify current cycle", "deadline":"Verify current cycle", "mcAT":"Verify current cycle",
        "notes":"Program availability and partner requirements should be checked for the student's admission year.", "url":""
    },
    {
        "program":"BS/DO / Early Assurance pathway", "undergrad":"New York Institute of Technology", "medical_school":"NYIT College of Osteopathic Medicine",
        "type":"BS/DO-type", "state":"NY", "city":"Old Westbury", "years":"Verify", "status":"Discovery lead — verify current official program",
        "minimums":"Verify current cycle", "deadline":"Verify current cycle", "mcAT":"Verify current cycle",
        "notes":"Use this row as a lead, not as an admissions fact until verified against the current NYIT catalog/admissions page.", "url":""
    },
    {
        "program":"Early Acceptance Program", "undergrad":"Multiple affiliated undergraduate institutions", "medical_school":"Lake Erie College of Osteopathic Medicine",
        "type":"Early Assurance / DO", "state":"PA", "city":"Erie", "years":"Varies", "status":"Discovery lead — verify affiliate and current requirements",
        "minimums":"Varies by affiliate and cycle", "deadline":"Varies", "mcAT":"Pathway-specific; verify",
        "notes":"LECOM pathways can involve multiple affiliated colleges. The app should eventually query current affiliate/program rules rather than treating this as one fixed BS/DO program.", "url":""
    },
]


def program_competitiveness(student_sat, gpa, program):
    """Conservative planning label. Combined medical programs are normally more selective than the host UG school."""
    if program["type"] in ("BA/BS–MD", "AB/ScB–MD", "BS/MD-type"):
        if student_sat >= 1530 and gpa >= 3.9:
            return "Reach"
        return "High Reach"
    if "DO" in program["type"]:
        if student_sat >= 1450 and gpa >= 3.8:
            return "Reach"
        return "High Reach"
    return "Reach / verify"
