MAJORS = {
    "Biology": {"bio":5,"chem":3,"math":1,"coding":0,"business":0,"people":2,"writing":1,"design":0,"health":4,"research":4},
    "Biochemistry": {"bio":5,"chem":5,"math":2,"coding":0,"business":0,"people":1,"writing":0,"design":0,"health":4,"research":5},
    "Neuroscience": {"bio":5,"chem":2,"math":2,"coding":1,"business":0,"people":3,"writing":1,"design":0,"health":5,"research":5},
    "Public Health": {"bio":3,"chem":1,"math":2,"coding":1,"business":1,"people":5,"writing":3,"design":0,"health":5,"research":3},
    "Psychology": {"bio":2,"chem":0,"math":1,"coding":0,"business":0,"people":5,"writing":4,"design":0,"health":3,"research":3},
    "Biomedical Engineering": {"bio":4,"chem":2,"math":5,"coding":3,"business":0,"people":1,"writing":0,"design":3,"health":5,"research":5},
    "Computer Science": {"bio":0,"chem":0,"math":5,"coding":5,"business":1,"people":1,"writing":0,"design":2,"health":0,"research":3},
    "Data Science": {"bio":1,"chem":0,"math":5,"coding":5,"business":2,"people":1,"writing":1,"design":0,"health":1,"research":4},
    "Economics": {"bio":0,"chem":0,"math":4,"coding":1,"business":5,"people":2,"writing":3,"design":0,"health":0,"research":2},
    "Finance": {"bio":0,"chem":0,"math":4,"coding":1,"business":5,"people":2,"writing":1,"design":0,"health":0,"research":1},
    "Accounting": {"bio":0,"chem":0,"math":3,"coding":1,"business":5,"people":1,"writing":1,"design":0,"health":0,"research":0},
    "Marketing": {"bio":0,"chem":0,"math":1,"coding":1,"business":5,"people":5,"writing":4,"design":3,"health":0,"research":1},
    "Mechanical Engineering": {"bio":0,"chem":1,"math":5,"coding":3,"business":0,"people":1,"writing":0,"design":5,"health":0,"research":4},
    "Chemical Engineering": {"bio":2,"chem":5,"math":5,"coding":2,"business":0,"people":1,"writing":0,"design":2,"health":2,"research":5},
    "Electrical Engineering": {"bio":0,"chem":0,"math":5,"coding":4,"business":0,"people":1,"writing":0,"design":4,"health":0,"research":4},
    "Nursing": {"bio":4,"chem":2,"math":1,"coding":0,"business":0,"people":5,"writing":1,"design":0,"health":5,"research":1},
    "Health Sciences": {"bio":4,"chem":2,"math":1,"coding":0,"business":0,"people":4,"writing":2,"design":0,"health":5,"research":2},
    "English / Humanities": {"bio":0,"chem":0,"math":0,"coding":0,"business":0,"people":3,"writing":5,"design":2,"health":1,"research":2},
    "Architecture / Design": {"bio":0,"chem":0,"math":3,"coding":1,"business":1,"people":2,"writing":1,"design":5,"health":0,"research":1},
}

KEYS = ["bio","chem","math","coding","business","people","writing","design","health","research"]


def recommend_majors(interests, broad_area="Undecided / General", max_results=8):
    """Return transparent similarity-based major suggestions, not aptitude diagnoses."""
    scored = []
    for major, vector in MAJORS.items():
        distance = sum(abs(interests.get(k,0) - vector.get(k,0)) for k in KEYS)
        max_distance = 5 * len(KEYS)
        score = round(100 * (1 - distance / max_distance))
        bonus = 0
        area = broad_area.lower()
        if ("pre-med" in area or "health" in area) and major in ["Biology","Biochemistry","Neuroscience","Public Health","Psychology","Biomedical Engineering","Health Sciences"]:
            bonus = 8
        elif "business" in area and major in ["Economics","Finance","Accounting","Marketing","Data Science"]:
            bonus = 8
        elif "engineering" in area and "Engineering" in major:
            bonus = 8
        elif ("computer" in area or "ai" in area) and major in ["Computer Science","Data Science","Electrical Engineering"]:
            bonus = 8
        elif "nursing" in area and major == "Nursing":
            bonus = 12
        scored.append((major, min(100, score + bonus), vector))
    return sorted(scored, key=lambda x: x[1], reverse=True)[:max_results]


def major_reason(major, interests, broad_area):
    reasons = []
    mapping = {
        "bio":"biology/life science", "chem":"chemistry", "math":"quantitative work",
        "coding":"coding/technology", "business":"business", "people":"people-facing work",
        "writing":"writing/communication", "design":"design/building", "health":"healthcare",
        "research":"research/discovery"
    }
    top = sorted(interests.items(), key=lambda x: x[1], reverse=True)[:3]
    reasons.append("matches your stronger interests in " + ", ".join(mapping[k] for k,v in top if v >= 3))
    if "pre-med" in broad_area.lower() or "health" in broad_area.lower():
        if major not in ["Nursing"]:
            reasons.append("can be paired with medical-school prerequisites if you choose the pre-med path")
    return "; ".join(reasons).capitalize() + "."
