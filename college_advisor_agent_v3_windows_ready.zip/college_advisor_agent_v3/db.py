import json
import os
import sqlite3
from pathlib import Path


def _db_path() -> Path:
    """Use a writable per-user data folder, including for the packaged .exe."""
    if os.name == "nt":
        root = Path(os.getenv("LOCALAPPDATA", Path.home())) / "CollegeAdmissionsAdvisor"
    else:
        root = Path.home() / ".college_admissions_advisor"
    root.mkdir(parents=True, exist_ok=True)
    return root / "college_advisor.db"


DB_PATH = _db_path()


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with connect() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS profiles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            data_json TEXT NOT NULL,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS saved_colleges (
            profile_name TEXT NOT NULL,
            unitid TEXT NOT NULL,
            school_name TEXT NOT NULL,
            status TEXT DEFAULT 'Saved',
            notes TEXT DEFAULT '',
            PRIMARY KEY(profile_name, unitid)
        );
        """)


def save_profile(name, data):
    with connect() as con:
        con.execute("""INSERT INTO profiles(name,data_json,updated_at) VALUES(?,?,CURRENT_TIMESTAMP)
                       ON CONFLICT(name) DO UPDATE SET data_json=excluded.data_json,updated_at=CURRENT_TIMESTAMP""",
                    (name, json.dumps(data)))


def load_profiles():
    with connect() as con:
        rows = con.execute("SELECT name,data_json FROM profiles ORDER BY name").fetchall()
    return {r["name"]: json.loads(r["data_json"]) for r in rows}


def save_college(profile_name, unitid, school_name, status="Saved", notes=""):
    with connect() as con:
        con.execute("""INSERT INTO saved_colleges(profile_name,unitid,school_name,status,notes) VALUES(?,?,?,?,?)
                       ON CONFLICT(profile_name,unitid) DO UPDATE SET school_name=excluded.school_name,status=excluded.status,notes=excluded.notes""",
                    (profile_name, str(unitid), school_name, status, notes))


def remove_college(profile_name, unitid):
    with connect() as con:
        con.execute("DELETE FROM saved_colleges WHERE profile_name=? AND unitid=?", (profile_name, str(unitid)))


def get_saved(profile_name):
    with connect() as con:
        rows = con.execute("SELECT * FROM saved_colleges WHERE profile_name=? ORDER BY school_name", (profile_name,)).fetchall()
    return [dict(r) for r in rows]
