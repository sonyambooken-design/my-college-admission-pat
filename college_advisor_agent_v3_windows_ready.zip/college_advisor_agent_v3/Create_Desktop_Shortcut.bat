@echo off
setlocal
cd /d "%~dp0"
set "TARGET=%CD%\dist\CollegeAdmissionsAdvisorV3\CollegeAdmissionsAdvisorV3.exe"
if not exist "%TARGET%" (
  echo The V3 executable has not been built yet.
  echo Run BUILD_WINDOWS_EXE.bat first.
  pause
  exit /b 1
)
powershell -NoProfile -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\College Admissions Advisor V3.lnk');$s.TargetPath='%TARGET%';$s.WorkingDirectory='%CD%\dist\CollegeAdmissionsAdvisorV3';$s.Save()"
echo Desktop shortcut created.
pause
