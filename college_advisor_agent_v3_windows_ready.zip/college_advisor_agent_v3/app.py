import os
import pandas as pd
import streamlit as st
from geopy.geocoders import Nominatim

from advisor import deterministic_advice, ai_advice
from db import init_db, load_profiles, save_profile, save_college, remove_college, get_saved
from fallback_data import COLLEGES as FALLBACK_COLLEGES
from scorecard import fetch_by_states, search_by_name
from scoring import (haversine, admission_category, admissions_fit, financial_fit,
                     location_fit, outcomes_fit, career_fit, overall_fit)
from major_advisor import recommend_majors, major_reason
from medical_pathways import PROGRAMS, program_competitiveness

st.set_page_config(page_title="College Admissions Advisor Agent V3", page_icon="🎓", layout="wide")
init_db()

AREAS = ["Pre-Med / Healthcare", "Business / Finance", "Engineering", "Computer Science / AI", "Nursing", "Undecided / General"]
DEFAULT_STATES = ["CT", "MA", "RI", "NY", "NJ", "VT", "NH"]
DEFAULT_HOME = {"label":"South Windsor, CT", "lat":41.8237, "lon":-72.6214, "state":"CT"}

@st.cache_data(ttl=86400, show_spinner=False)
def geocode_place(place):
    if place.strip().lower() == "south windsor, ct":
        return DEFAULT_HOME
    geo = Nominatim(user_agent="college-advisor-agent-v2")
    loc = geo.geocode(place + ", USA", country_codes="us", timeout=8)
    if not loc:
        return None
    # State is inferred separately by user input to avoid brittle reverse-geocoding.
    return {"label": place, "lat": loc.latitude, "lon": loc.longitude}

@st.cache_data(ttl=21600, show_spinner=False)
def load_live_colleges(states, api_key):
    return fetch_by_states(tuple(states), api_key=api_key)


def fmt_money(v):
    return f"${int(v):,}" if pd.notna(v) and v is not None else "—"


def score_colleges(colleges, profile, weights):
    rows = []
    for c in colleges:
        if c.get("lat") is None or c.get("lon") is None:
            distance = None
        else:
            distance = haversine(profile["lat"], profile["lon"], float(c["lat"]), float(c["lon"]))
        adm = admissions_fit(profile["sat"], profile["gpa"], c.get("sat_avg"), c.get("acceptance_rate"))
        fin = financial_fit(c.get("net_price"), c.get("tuition_in"), c.get("tuition_out"), profile["budget"], profile["home_state"], c.get("state"), "Public" if c.get("ownership") == "Public" else "Private")
        loc = location_fit(distance, profile["radius"])
        out = outcomes_fit(c.get("grad_rate"), c.get("earnings_10yr"))
        career = career_fit(profile["area"], c.get("school"), c.get("ownership"), c.get("enrollment"), c.get("grad_rate"))
        scores = {"Admissions": adm, "Career": career, "Financial": fin, "Outcomes": out, "Location": loc}
        x = dict(c)
        x.update({
            "distance": round(distance,1) if distance is not None else None,
            "admission_category": admission_category(profile["sat"], c.get("sat_avg"), c.get("acceptance_rate")),
            "admissions_fit": adm, "financial_fit": fin, "location_fit": loc,
            "outcomes_fit": out, "career_fit": career,
            "overall_fit": overall_fit(scores, weights)
        })
        rows.append(x)
    return pd.DataFrame(rows)

st.title("🎓 College Admissions Advisor Agent — Version 3")
st.caption("College fit • Medical Pathways • Major Finder • persistent profiles • AI-ready advisor")

profiles = load_profiles()
with st.sidebar:
    st.header("Student Profile")
    existing = st.selectbox("Load saved profile", ["New profile"] + list(profiles.keys()))
    loaded = profiles.get(existing, {})
    name = st.text_input("Student name", loaded.get("name", existing if existing != "New profile" else "Student 1"))
    gpa = st.number_input("GPA", 0.0, 5.0, float(loaded.get("gpa", 4.10)), 0.01)
    sat = st.number_input("SAT", 400, 1600, int(loaded.get("sat", 1450)), 10)
    area = st.selectbox("Broad area", AREAS, index=AREAS.index(loaded.get("area", AREAS[0])) if loaded.get("area", AREAS[0]) in AREAS else 0)
    home_text = st.text_input("Home town or ZIP", loaded.get("home_text", "South Windsor, CT"))
    home_state = st.text_input("Home state abbreviation", loaded.get("home_state", "CT"), max_chars=2).upper()
    radius = st.slider("Search radius (miles)", 25, 500, int(loaded.get("radius", 200)), 25)
    budget = st.slider("Target annual net cost", 10000, 100000, int(loaded.get("budget", 55000)), 5000)
    scan_states = st.multiselect("States to scan for nearby colleges", ["CT","MA","RI","NY","NJ","VT","NH","ME","PA","DE"], default=loaded.get("scan_states", DEFAULT_STATES))
    college_type = st.selectbox("College type", ["Any","Public","Private nonprofit"], index=0)
    st.divider()
    st.subheader("Data connection")
    api_key_input = st.text_input("College Scorecard API key (optional)", type="password", help="Used only for this running session. If blank, the app uses COLLEGE_SCORECARD_API_KEY or DEMO_KEY.")
    st.divider()
    st.subheader("Fit weights")
    wadm = st.slider("Admissions",0,50,25); wcareer = st.slider("Career",0,50,25)
    wfin = st.slider("Financial",0,50,20); wout = st.slider("Outcomes",0,50,20); wloc = st.slider("Location",0,50,10)
    weights = {"Admissions":wadm,"Career":wcareer,"Financial":wfin,"Outcomes":wout,"Location":wloc}
    if st.button("Save student profile", use_container_width=True):
        home = geocode_place(home_text)
        if home:
            data = {"name":name,"gpa":gpa,"sat":sat,"area":area,"home_text":home_text,"home_state":home_state,"radius":radius,"budget":budget,"scan_states":scan_states}
            save_profile(name, data)
            st.success("Profile saved")
        else:
            st.error("Could not locate that home location.")

home = geocode_place(home_text)
if not home:
    st.error("I could not geocode the home town/ZIP. Try 'South Windsor, CT' or another city + state.")
    st.stop()

profile = {"name":name,"gpa":gpa,"sat":sat,"area":area,"lat":home["lat"],"lon":home["lon"],"home_state":home_state,"radius":radius,"budget":budget}

api_key = api_key_input.strip() or os.getenv("COLLEGE_SCORECARD_API_KEY", "DEMO_KEY")
try:
    with st.spinner("Loading College Scorecard data…"):
        colleges = load_live_colleges(scan_states, api_key)
    source_mode = "Live College Scorecard"
except Exception as e:
    colleges = FALLBACK_COLLEGES
    source_mode = "Offline fallback"
    st.warning("Live College Scorecard data could not be loaded, so V3 is using its small offline fallback dataset. Add a free api.data.gov key for more reliable live access.")

scored = score_colleges(colleges, profile, weights)
if not scored.empty:
    scored = scored[(scored["distance"].isna()) | (scored["distance"] <= radius)].copy()
    if college_type != "Any":
        scored = scored[scored["ownership"] == college_type]
    scored = scored.sort_values(["overall_fit","career_fit"], ascending=False)

m1,m2,m3,m4 = st.columns(4)
m1.metric("Matching colleges", len(scored))
m2.metric("Top fit", f"{int(scored.iloc[0].overall_fit)}/100" if len(scored) else "—")
m3.metric("Career area", area.split("/")[0].strip())
m4.metric("Data mode", source_mode)

st.info("Admission categories and pathway competitiveness are planning heuristics, not admission probabilities. Objective institutional metrics come from College Scorecard when live mode is available.")

tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(["Recommendations","Medical Pathways","Major Finder","Saved List","Compare","Ask the Advisor"])

with tab1:
    st.subheader("Recommended colleges")
    if scored.empty:
        st.warning("No colleges match the current radius/filters. Expand the radius or scan more states.")
    else:
        top = scored.head(30).copy()
        top["Acceptance"] = top["acceptance_rate"].apply(lambda x: f"{x:.0%}" if pd.notna(x) else "—")
        top["Grad Rate"] = top["grad_rate"].apply(lambda x: f"{x:.0%}" if pd.notna(x) else "—")
        top["Net Price"] = top["net_price"].apply(fmt_money)
        top["Tuition OOS"] = top["tuition_out"].apply(fmt_money)
        display = top[["school","city","state","distance","overall_fit","admission_category","sat_avg","Acceptance","Net Price","Tuition OOS","career_fit","Grad Rate"]]
        display.columns = ["School","City","State","Miles","Fit","Admission","SAT Avg","Acceptance","Avg Net Price","OOS Tuition","Career Fit*","Grad Rate"]
        st.dataframe(display, hide_index=True, use_container_width=True)
        st.caption("*Career Fit is the app's advisory proxy, not a College Scorecard metric.")

        st.markdown("### Top recommendations explained")
        for _, r in top.head(7).iterrows():
            rr = r.to_dict()
            st.markdown(f"**{rr['school']} — {rr['overall_fit']}/100 · {rr['admission_category']}**  ")
            st.write(deterministic_advice(rr, area, budget))
            c1,c2,c3 = st.columns([1,1,4])
            if c1.button("Save", key=f"save-{rr['unitid']}"):
                save_college(name, rr['unitid'], rr['school'])
                st.toast(f"Saved {rr['school']}")
            c2.caption(f"{rr['distance']} mi" if rr['distance'] is not None else "distance n/a")

    st.markdown("### Add a college anywhere in the U.S.")
    q = st.text_input("College name", placeholder="e.g., Duke University")
    if st.button("Search college name") and q.strip():
        try:
            hits = search_by_name(q.strip(), api_key=api_key)
            if hits:
                hdf = pd.DataFrame(hits)
                st.dataframe(hdf[["unitid","school","city","state","sat_avg","net_price"]], hide_index=True, use_container_width=True)
                for h in hits[:10]:
                    if st.button(f"Save {h['school']}", key=f"manual-{h['unitid']}"):
                        save_college(name, h['unitid'], h['school'])
                        st.success("Saved")
            else:
                st.warning("No matching college found.")
        except Exception as e:
            st.error("College name search failed. Check the API key/network connection.")

with tab2:
    st.subheader("Medical Pathways: BS/MD, BS/DO & Early Assurance")
    st.write("Use this module to discover direct/conditional medical pathways separately from ordinary undergraduate admission.")
    ptype = st.multiselect("Program type", sorted(set(p["type"] for p in PROGRAMS)), default=sorted(set(p["type"] for p in PROGRAMS)))
    pstate = st.multiselect("States", sorted(set(p["state"] for p in PROGRAMS)), default=sorted(set(p["state"] for p in PROGRAMS)))
    med_rows = []
    for p in PROGRAMS:
        if p["type"] in ptype and p["state"] in pstate:
            x = dict(p)
            x["Planning Category"] = program_competitiveness(sat, gpa, p)
            med_rows.append(x)
    if med_rows:
        mdf = pd.DataFrame(med_rows)
        st.dataframe(mdf[["program","undergrad","medical_school","type","state","years","Planning Category","status"]], hide_index=True, use_container_width=True)
        choice = st.selectbox("View pathway details", [x["program"] + " — " + x["undergrad"] for x in med_rows])
        pp = med_rows[[x["program"] + " — " + x["undergrad"] for x in med_rows].index(choice)]
        st.markdown(f"### {pp['program']}")
        st.write(f"**Undergraduate:** {pp['undergrad']}  \n**Medical school:** {pp['medical_school']}  \n**Type:** {pp['type']}  \n**Your planning category:** {pp['Planning Category']}")
        st.write(f"**Requirements/minimums:** {pp['minimums']}")
        st.write(f"**Deadline:** {pp['deadline']}")
        st.write(f"**MCAT:** {pp['mcAT']}")
        st.write(pp["notes"])
        if pp.get("url"):
            st.link_button("Open official program page", pp["url"])
        if "Discovery lead" in pp["status"]:
            st.warning("This is a discovery lead, not verified current-cycle admissions data. Confirm the program on the university/medical school website before making an application decision.")
    st.caption("Combined medical programs are scored separately from ordinary undergraduate admission because the medical pathway is typically much more selective.")

with tab3:
    st.subheader("Undergraduate Major Finder")
    st.write("Rate how much the student enjoys each activity. The result suggests majors to investigate; it is not an aptitude test or career diagnosis.")
    c1,c2 = st.columns(2)
    with c1:
        ibio = st.slider("Biology / living systems",0,5,4)
        ichem = st.slider("Chemistry",0,5,3)
        imath = st.slider("Math / quantitative problems",0,5,3)
        icode = st.slider("Coding / technology",0,5,2)
        ibiz = st.slider("Business / markets",0,5,2)
    with c2:
        ipeople = st.slider("Working directly with people",0,5,4)
        iwrite = st.slider("Writing / communication",0,5,3)
        idesign = st.slider("Designing / building things",0,5,2)
        ihealth = st.slider("Healthcare / patient impact",0,5,5)
        iresearch = st.slider("Research / discovery",0,5,4)
    interests = {"bio":ibio,"chem":ichem,"math":imath,"coding":icode,"business":ibiz,"people":ipeople,"writing":iwrite,"design":idesign,"health":ihealth,"research":iresearch}
    major_results = recommend_majors(interests, area)
    st.markdown("### Suggested majors to investigate")
    for i,(major,mscore,vec) in enumerate(major_results,1):
        st.markdown(f"**{i}. {major} — match {mscore}/100**")
        st.write(major_reason(major, interests, area))
    if "pre-med" in area.lower() or "health" in area.lower():
        st.info("For pre-med, the major and the medical-school prerequisite sequence are separate decisions. A student can major outside Biology as long as required science courses and other medical-school requirements are completed.")

with tab4:
    st.subheader(f"{name}'s saved college list")
    saved = get_saved(name)
    if not saved:
        st.write("No colleges saved yet.")
    else:
        sdf = pd.DataFrame(saved)
        st.dataframe(sdf[["school_name","status","notes"]], hide_index=True, use_container_width=True)
        status_choices = ["Saved","Researching","Visit Planned","Visited","Applying","Submitted","Accepted","Waitlisted","Denied"]
        school_to_edit = st.selectbox("Update a school", [x["school_name"] for x in saved])
        item = next(x for x in saved if x["school_name"] == school_to_edit)
        status = st.selectbox("Status", status_choices, index=status_choices.index(item["status"]) if item["status"] in status_choices else 0)
        notes = st.text_area("Notes", item.get("notes", ""))
        c1,c2 = st.columns(2)
        if c1.button("Update saved school"):
            save_college(name, item["unitid"], item["school_name"], status, notes)
            st.success("Updated")
        if c2.button("Remove from list"):
            remove_college(name, item["unitid"])
            st.success("Removed. Refresh the page to see the updated list.")

        # Balance check using currently loaded scored data for saved nearby schools.
        local_saved = scored[scored["unitid"].astype(str).isin([str(x["unitid"]) for x in saved])] if not scored.empty else pd.DataFrame()
        if not local_saved.empty:
            counts = local_saved["admission_category"].value_counts().to_dict()
            st.markdown("### Balanced-list check")
            st.write(" · ".join(f"**{k}:** {counts.get(k,0)}" for k in ["Likely","Target","Reach","High Reach"]))
            if counts.get("Likely",0) < 2:
                st.warning("Consider adding at least two academically and financially realistic Likely schools.")

with tab5:
    st.subheader("Side-by-side comparison")
    if scored.empty:
        st.write("No colleges available to compare.")
    else:
        picks = st.multiselect("Choose 2–5 colleges", scored["school"].tolist(), max_selections=5)
        if len(picks) >= 2:
            comp = scored[scored["school"].isin(picks)].copy()
            comp["Acceptance"] = comp["acceptance_rate"].apply(lambda x: f"{x:.0%}" if pd.notna(x) else "—")
            comp["Net Price"] = comp["net_price"].apply(fmt_money)
            st.dataframe(comp[["school","overall_fit","admission_category","sat_avg","Acceptance","Net Price","distance","career_fit","outcomes_fit"]], hide_index=True, use_container_width=True)

with tab6:
    st.subheader("Ask the Advisor")
    st.write("Ask a natural-language college, major, BS/MD or BS/DO question. With OPENAI_API_KEY configured the app can use AI; without it, V3 provides guided answers for common questions plus the deterministic list brief.")
    question = st.text_area("Your question", placeholder="e.g., Which BS/MD or BS/DO pathways should I investigate with a 1450 SAT? Or which undergraduate majors fit a pre-med student who likes math and technology?")
    if st.button("Answer my question", type="primary") and question.strip():
        qlow = question.lower()
        if any(k in qlow for k in ["bs/md","bsmd","bs-do","bs/do","do program","medical pathway","early assurance"]):
            st.markdown("**Medical-pathway starting points:**")
            for p in PROGRAMS:
                st.write(f"• **{p['program']} — {p['undergrad']} ({p['type']}):** {program_competitiveness(sat,gpa,p)} for planning. {p['status']}.")
            st.caption("Use the Medical Pathways tab for details. Verify all program rules for the actual application cycle.")
        elif any(k in qlow for k in ["major","study","undergrad field","undergraduate field"]):
            st.write("Use the Major Finder tab to rate interests. The agent will rank majors and explain why they fit; pre-med prerequisites remain separate from the major.")
        else:
            records = scored.head(12).to_dict("records") if not scored.empty else []
            text = ai_advice(profile, records)
            if text: st.write(text)
            elif records:
                for r in records[:5]: st.write(f"• **{r['school']} ({r['admission_category']}, {r['overall_fit']}/100):** {deterministic_advice(r, area, budget)}")
            else: st.warning("No colleges available for an advisory answer.")
    st.divider()
    st.markdown("### Generate overall college-list brief")
    if st.button("Generate my college-list brief", type="primary"):
        records = scored.head(12).to_dict("records") if not scored.empty else []
        text = ai_advice(profile, records)
        if text:
            st.write(text)
        elif records:
            st.markdown("**Your current strongest fits:**")
            for r in records[:5]:
                st.write(f"• **{r['school']} ({r['admission_category']}, {r['overall_fit']}/100):** {deterministic_advice(r, area, budget)}")
            cats = pd.Series([r["admission_category"] for r in records]).value_counts().to_dict()
            if cats.get("Likely",0) < 2:
                st.warning("Your top results are reach/target heavy. Add at least two Likely schools before finalizing your list.")
        else:
            st.warning("No colleges available for an advisory brief.")

st.divider()
st.caption("V3 data note: College Scorecard provides federal institution-level metrics. BS/MD, BS/DO, early-assurance rules and major requirements can change by cycle; always verify program-specific requirements on official university and medical-school websites before applying.")
st.markdown(
    "<div style='text-align:center; opacity:0.48; font-size:0.72rem; margin-top:0.7rem;'>Created by S. Ambooken</div>",
    unsafe_allow_html=True,
)
