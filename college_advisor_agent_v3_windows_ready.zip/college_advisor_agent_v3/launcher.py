"""Windows desktop launcher for College Admissions Advisor.

This file is packaged with PyInstaller by BUILD_WINDOWS_EXE.bat.
"""
import os
import socket
import sys
import threading
import time
import webbrowser
from pathlib import Path

# Explicit imports help PyInstaller discover dependencies used by the Streamlit app.
import pandas  # noqa: F401
import requests  # noqa: F401
import streamlit  # noqa: F401
import geopy  # noqa: F401
try:
    import openai  # noqa: F401
except Exception:
    pass

import advisor  # noqa: F401
import db  # noqa: F401
import fallback_data  # noqa: F401
import scorecard  # noqa: F401
import scoring  # noqa: F401
import major_advisor  # noqa: F401
import medical_pathways  # noqa: F401


def resource_dir() -> Path:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def open_browser_later(url: str) -> None:
    time.sleep(1.8)
    webbrowser.open(url)


def main() -> int:
    base = resource_dir()
    app = base / "app.py"
    if not app.exists():
        raise FileNotFoundError(f"Application file not found: {app}")

    port = free_port()
    url = f"http://127.0.0.1:{port}"
    threading.Thread(target=open_browser_later, args=(url,), daemon=True).start()

    # Keep Streamlit quiet and local. The browser opens automatically above.
    os.environ.setdefault("STREAMLIT_BROWSER_GATHER_USAGE_STATS", "false")
    os.environ.setdefault("STREAMLIT_SERVER_HEADLESS", "true")
    os.environ["STREAMLIT_GLOBAL_DEVELOPMENT_MODE"] = "false"

    from streamlit.web import cli as stcli
    sys.argv = [
        "streamlit",
        "run",
        str(app),
        "--global.developmentMode=false",
        "--server.address=127.0.0.1",
        f"--server.port={port}",
        "--server.headless=true",
        "--browser.gatherUsageStats=false",
    ]
    return int(stcli.main() or 0)


if __name__ == "__main__":
    raise SystemExit(main())
