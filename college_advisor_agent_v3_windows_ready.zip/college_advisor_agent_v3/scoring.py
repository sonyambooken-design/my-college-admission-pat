import math


def clamp(v, low=0.0, high=100.0):
    return max(low, min(high, v))


def haversine(lat1, lon1, lat2, lon2):
    r = 3958.8
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlambda / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def admission_category(student_sat, sat_avg, acceptance_rate):
    """Heuristic category, not an admissions probability."""
    if sat_avg is None:
        if acceptance_rate is None:
            return "Uncertain"
        if acceptance_rate <= 0.12:
            return "High Reach"
        if acceptance_rate <= 0.30:
            return "Reach"
        if acceptance_rate >= 0.70:
            return "Likely"
        return "Target"

    gap = student_sat - sat_avg
    ar = acceptance_rate if acceptance_rate is not None else 0.50
    if ar <= 0.10:
        return "Reach" if gap >= 80 else "High Reach"
    if ar <= 0.25:
        return "Target" if gap >= 100 else ("Reach" if gap >= -30 else "High Reach")
    if ar <= 0.50:
        return "Likely" if gap >= 120 else ("Target" if gap >= 0 else "Reach")
    if gap >= 80:
        return "Likely"
    if gap >= -70:
        return "Target"
    return "Reach"


def admissions_fit(student_sat, gpa, sat_avg, acceptance_rate):
    if sat_avg is None:
        base = 60
    else:
        base = 70 + (student_sat - sat_avg) * 0.12
    if acceptance_rate is not None:
        base += (acceptance_rate - 0.45) * 18
    # Small bounded GPA modifier because weighted/unweighted scales differ.
    base += clamp((gpa - 3.6) * 10, -5, 7)
    return round(clamp(base, 20, 100))


def financial_fit(net_price, tuition_in, tuition_out, budget, home_state, school_state, ownership):
    sticker = tuition_in if (ownership == "Public" and home_state == school_state and tuition_in) else tuition_out
    effective = net_price or sticker
    if effective is None:
        return 60
    if effective <= budget:
        return round(clamp(88 + (budget - effective) / max(budget, 1) * 20, 20, 100))
    return round(clamp(88 - (effective - budget) / max(budget, 1) * 80, 20, 100))


def location_fit(distance, radius):
    if distance is None:
        return 50
    if distance <= radius * 0.25:
        return 100
    if distance <= radius:
        return round(clamp(100 - 35 * (distance / radius), 60, 100))
    return round(clamp(55 - 40 * ((distance - radius) / max(radius, 1)), 10, 55))


def outcomes_fit(grad_rate, earnings):
    score = 60
    if grad_rate is not None:
        score = grad_rate * 100
    if earnings is not None:
        earnings_component = clamp(45 + (earnings - 45000) / 1000, 35, 100)
        score = 0.7 * score + 0.3 * earnings_component
    return round(clamp(score, 20, 100))


def career_fit(area, school_name, ownership, enrollment, grad_rate):
    """V2 advisory proxy. It is intentionally not presented as federal data."""
    base = 68
    name = (school_name or "").lower()
    if enrollment and enrollment > 12000:
        base += 5  # proxy for breadth/research opportunity
    if grad_rate and grad_rate >= 0.80:
        base += 6

    area = area.lower()
    if "pre-med" in area or "health" in area:
        if any(k in name for k in ["university", "college"]): base += 4
    elif "business" in area:
        if any(k in name for k in ["university", "college"]): base += 3
    elif "engineering" in area or "computer" in area or "ai" in area:
        if any(k in name for k in ["technology", "polytechnic", "institute"]): base += 12
    elif "nursing" in area:
        if "university" in name: base += 4
    return round(clamp(base, 45, 92))


def overall_fit(scores, weights):
    total = sum(weights.values()) or 1
    return round(sum(scores[k] * weights[k] for k in weights) / total)
