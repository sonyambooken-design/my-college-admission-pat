import os
import requests

BASE_URL = "https://api.data.gov/ed/collegescorecard/v1/schools.json"
FIELDS = [
    "id","school.name","school.city","school.state","school.zip","school.ownership",
    "location.lat","location.lon",
    "latest.student.size","latest.admissions.admission_rate.overall",
    "latest.admissions.sat_scores.average.overall",
    "latest.cost.tuition.in_state","latest.cost.tuition.out_of_state",
    "latest.cost.avg_net_price.overall","latest.completion.completion_rate_4yr_150nt",
    "latest.earnings.10_yrs_after_entry.median"
]


def _ownership(v):
    return {1: "Public", 2: "Private nonprofit", 3: "Private for-profit"}.get(v, "Other")


def _normalize(x):
    lat = x.get("location.lat")
    lon = x.get("location.lon")
    return {
        "unitid": x.get("id"),
        "school": x.get("school.name"),
        "city": x.get("school.city"),
        "state": x.get("school.state"),
        "zip": x.get("school.zip"),
        "ownership": _ownership(x.get("school.ownership")),
        "lat": lat,
        "lon": lon,
        "enrollment": x.get("latest.student.size"),
        "acceptance_rate": x.get("latest.admissions.admission_rate.overall"),
        "sat_avg": x.get("latest.admissions.sat_scores.average.overall"),
        "tuition_in": x.get("latest.cost.tuition.in_state"),
        "tuition_out": x.get("latest.cost.tuition.out_of_state"),
        "net_price": x.get("latest.cost.avg_net_price.overall"),
        "grad_rate": x.get("latest.completion.completion_rate_4yr_150nt"),
        "earnings_10yr": x.get("latest.earnings.10_yrs_after_entry.median"),
        "source": "College Scorecard"
    }


def fetch_by_states(states, api_key=None, per_page=100, max_pages_per_state=6):
    key = api_key or os.getenv("COLLEGE_SCORECARD_API_KEY", "DEMO_KEY")
    out = []
    seen = set()
    for state in states:
        for page in range(max_pages_per_state):
            params = {
                "api_key": key,
                "school.state": state,
                "school.degrees_awarded.predominant": "3",
                "fields": ",".join(FIELDS),
                "per_page": per_page,
                "page": page,
            }
            r = requests.get(BASE_URL, params=params, timeout=20)
            r.raise_for_status()
            payload = r.json()
            results = payload.get("results", [])
            if not results:
                break
            for raw in results:
                item = _normalize(raw)
                if item["unitid"] not in seen:
                    seen.add(item["unitid"])
                    out.append(item)
            if len(results) < per_page:
                break
    return out


def search_by_name(name, api_key=None, per_page=20):
    key = api_key or os.getenv("COLLEGE_SCORECARD_API_KEY", "DEMO_KEY")
    params = {
        "api_key": key,
        "school.name": name,
        "fields": ",".join(FIELDS),
        "per_page": per_page,
    }
    r = requests.get(BASE_URL, params=params, timeout=20)
    r.raise_for_status()
    return [_normalize(x) for x in r.json().get("results", [])]
