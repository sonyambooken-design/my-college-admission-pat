import json
import os


def deterministic_advice(row, area, budget):
    parts = []
    if row.get("career_fit", 0) >= 78:
        parts.append(f"good {area} advisory fit")
    if row.get("admissions_fit", 0) >= 80:
        parts.append("strong academic alignment")
    if row.get("financial_fit", 0) >= 85:
        parts.append("cost aligns well with your target")
    if row.get("location_fit", 0) >= 85:
        parts.append("conveniently located")
    if row.get("outcomes_fit", 0) >= 85:
        parts.append("strong completion/outcome indicators")
    if not parts:
        parts = ["balanced overall profile"]
    caution = []
    if row.get("admission_category") in ("Reach", "High Reach"):
        caution.append("admission is selective")
    if row.get("net_price") and row["net_price"] > budget:
        caution.append("estimated net price is above your target")
    msg = ", ".join(parts[:3]).capitalize() + "."
    if caution:
        msg += " Watch: " + "; ".join(caution) + "."
    return msg


def ai_advice(profile, colleges):
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        return None
    try:
        from openai import OpenAI
        client = OpenAI(api_key=key)
        model = os.getenv("OPENAI_MODEL", "gpt-5-mini")
        compact = [{k: c.get(k) for k in ["school","overall_fit","admission_category","distance","net_price","sat_avg","career_fit"]} for c in colleges[:8]]
        prompt = (
            "You are a careful college admissions advisor. Do not guarantee admission. "
            "Use only the supplied data. Explain the strongest 5 schools and identify list-balance issues. "
            "Career-fit is an advisory proxy, not official federal data.\n\n"
            f"Student profile: {json.dumps(profile)}\nColleges: {json.dumps(compact)}"
        )
        res = client.responses.create(model=model, input=prompt)
        return res.output_text
    except Exception:
        return None
