@echo off
setlocal
cd /d "%~dp0"
title College Admissions Advisor V3 - Windows EXE Builder

echo ============================================================
echo  College Admissions Advisor Agent V3 - EXE Builder
echo  Created by S. Ambooken
echo ============================================================
echo.

where py >nul 2>&1
if %errorlevel%==0 (
  set "PY=py"
) else (
  where python >nul 2>&1
  if %errorlevel%==0 (
    set "PY=python"
  ) else (
    echo ERROR: Python was not found on this computer.
    echo Install Python 3.11 or 3.12 from python.org and select
    echo "Add Python to PATH", then run this file again.
    pause
    exit /b 1
  )
)

if not exist ".buildvenv\Scripts\python.exe" (
  echo [1/4] Creating build environment...
  %PY% -m venv .buildvenv
  if errorlevel 1 goto :failed
) else (
  echo [1/4] Reusing build environment...
)

call ".buildvenv\Scripts\activate.bat"
echo [2/4] Installing dependencies...
python -m pip install --upgrade pip
if errorlevel 1 goto :failed
python -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto :failed

echo [3/4] Building Windows application...
python -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --windowed ^
  --name "CollegeAdmissionsAdvisorV3" ^
  --collect-all streamlit ^
  --collect-all altair ^
  --collect-all pydeck ^
  --collect-all geopy ^
  --hidden-import openai ^
  --add-data "app.py;." ^
  --add-data "major_advisor.py;." ^
  --add-data "medical_pathways.py;." ^
  --add-data "advisor.py;." ^
  --add-data "db.py;." ^
  --add-data "fallback_data.py;." ^
  --add-data "scorecard.py;." ^
  --add-data "scoring.py;." ^
  launcher.py
if errorlevel 1 goto :failed

echo [4/4] Build complete.
echo.
echo Your executable is:
echo   %CD%\dist\CollegeAdmissionsAdvisorV3\CollegeAdmissionsAdvisorV3.exe
echo.
start "" "%CD%\dist\CollegeAdmissionsAdvisorV3"
pause
exit /b 0

:failed
echo.
echo BUILD FAILED. Copy the error text above and send it for troubleshooting.
pause
exit /b 1
